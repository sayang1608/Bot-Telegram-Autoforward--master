/* eslint-disable prettier/prettier */
import { SaveStorage } from "./saveStorage"

/**
 * Session Manajemen for forward ID and more
 */
const checkWorker = (label: string, idFromUser: number) => {
    const filePath = SaveStorage.checkFileSessionExist("forwardWorker")
    const workers = SaveStorage.loadSession(filePath)

    const findSameWorkers = workers.filter(({ worker, id }) => {
        return worker === label && id == idFromUser
    })[0];

    if (findSameWorkers) {
        return true;
    }
    return false;
}

const resultSplitId = (argAction: string, argLabel: string, argCommand: string) => {
    /**
     * argCommand => /forward add worker1 <IdFrom> -> <IdTo>
     */
    const lenActionAndLabel = argAction.length + argLabel.length
    const forwardChatId = argCommand.slice(lenActionAndLabel + 1, argCommand.length)
    const from = forwardChatId.split("->")[0].trim();
    const to = forwardChatId.split("->")[1].trim();
    console.log(from, " <= from");
    console.log(to, " <= to");

    const froms = from.split(',');
    const toMany = to.split(',');

    return { froms, toMany };
}

const loadWorkers = () => {
    const filePath = SaveStorage.checkFileSessionExist('forwardWorker')
    const workers = SaveStorage.loadSession(filePath)
    
    return workers
}

const saveToStorage = (forwardInfo: any) => {
    return SaveStorage.set(forwardInfo, 'forwardWorker')
}

export { resultSplitId, saveToStorage, loadWorkers, checkWorker }